package principal;

import model.Desconto;
import model.DescontoPorItens;
import model.DescontoPorValor;
import model.Pedido;
import model.SemDesconto;

public class Teste {

		public static void main(String[] args) {
			
		       Pedido pedido = new Pedido (500.0, 25);
		       Double pedidoComDesconto = calculaDesconto(pedido);
		       System.out.println("O valor do pedido com desconto �: " + (pedidoComDesconto));
		   }   
		 
		   public static Double calculaDesconto(Pedido pedido) {
		        final Desconto descontoPorItem = new DescontoPorItens();
		        final Desconto descontoPorValor = new DescontoPorValor();
		        final Desconto semDesconto = new SemDesconto();
		 
		        descontoPorItem.setProximo(descontoPorValor);
		        descontoPorValor.setProximo(semDesconto);
		 
		        return descontoPorItem.calcular(pedido);
		   }
}
