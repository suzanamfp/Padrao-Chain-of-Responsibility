package model;



public class Pedido {
	
	private Double valor;
	private int itens;
	
	public Pedido(Double valor, int itens) {
		super();
		this.valor = valor;
		this.itens = itens;
	}

	public Double getValor() {
		return valor;
	}

	public void setValor(Double valor) {
		this.valor = valor;
	}

	public int getItens() {
		return itens;
	}

	public void setItens(int itens) {
		this.itens = itens;
	}
	
	
}