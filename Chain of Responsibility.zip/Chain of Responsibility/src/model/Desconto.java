package model;

public interface Desconto {
		 
	    Double calcular(Pedido pedido);
	 
	    void setProximo(Desconto proximo);
	
}
