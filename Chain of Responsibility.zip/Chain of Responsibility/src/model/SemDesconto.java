package model;

public class SemDesconto implements Desconto {
	     
	    @Override
	    public Double calcular(Pedido pedido) {
	       return 0.0;
	    }
	 
	    @Override
	    public void setProximo(Desconto desconto) {
	       // N�o faz nada, � o �ltimo n�vel
	    }
	}
