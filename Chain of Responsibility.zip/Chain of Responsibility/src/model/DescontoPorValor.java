package model;

import model.Desconto;
import model.Pedido;

public class DescontoPorValor implements Desconto {
        
     private Desconto proximo;
 
     @Override
     public Double calcular(Pedido pedido) {
        if(pedido.getValor() > 1000.0) {
            return pedido.getValor() * (0.10);
        } else {
            return proximo.calcular(pedido);
       }
     }
 
     @Override
     public void setProximo(Desconto proximo) {
         this.proximo = proximo;
     }

	
}


