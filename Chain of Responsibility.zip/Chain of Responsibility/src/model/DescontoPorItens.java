package model;

public class DescontoPorItens implements Desconto {
        
	    private Desconto proximo;
	    
	    
	    @Override
		public Double calcular(Pedido pedido) {
			if(pedido.getItens() > 20) {
				return pedido.getValor() * (0.5);				
			}
			else {
				
				return proximo.calcular(pedido);
			}
			
	    }	
		
	    
	    @Override
	    public void setProximo(Desconto proximo) {
	       this.proximo = proximo;
	       }


		
	 

}
